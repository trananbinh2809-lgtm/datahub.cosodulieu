import React from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext.js';
import { MainLayout } from '../layouts/MainLayout.js';
import { AuthLayout } from '../layouts/AuthLayout.js';
import { LoadingSpinner } from '../components/common/Card.js';

// Pages
import { LoginPage } from '../pages/auth/LoginPage.js';
import { RegisterPage } from '../pages/auth/RegisterPage.js';
import { DashboardPage } from '../pages/dashboard/DashboardPage.js';
import { ProjectsPage } from '../pages/projects/ProjectsPage.js';
import { ProjectDetailPage } from '../pages/projects/ProjectDetailPage.js';
import { DatasetsPage } from '../pages/datasets/DatasetsPage.js';
import { NormalizationPage } from '../pages/normalization/NormalizationPage.js';
import { VersionsPage } from '../pages/versions/VersionsPage.js';
import { ChatPage } from '../pages/chat/ChatPage.js';
import { NotificationsPage } from '../pages/notifications/NotificationsPage.js';
import { ProfilePage } from '../pages/profile/ProfilePage.js';
import { SettingsPage } from '../pages/settings/SettingsPage.js';
import { AdminPage } from '../pages/admin/AdminPage.js';

// Route Guard for authenticated users
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950">
        <LoadingSpinner text="Đang tải phiên làm việc DataHub..." />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
};

// Route Guard to redirect already logged in users away from login/register
const PublicOnlyRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) return null;
  if (user) return <Navigate to="/" replace />;
  return <>{children}</>;
};

export const AppRoutes: React.FC = () => {
  return (
    <Routes>
      {/* Auth Layout for Public Auth Pages */}
      <Route
        element={
          <PublicOnlyRoute>
            <AuthLayout />
          </PublicOnlyRoute>
        }
      >
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
      </Route>

      {/* Main Layout for Authenticated Pages */}
      <Route
        element={
          <ProtectedRoute>
            <MainLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/" element={<DashboardPage />} />
        <Route path="/projects" element={<ProjectsPage />} />
        <Route path="/projects/:id" element={<ProjectDetailPage />} />
        <Route path="/datasets" element={<DatasetsPage />} />
        <Route path="/normalization" element={<NormalizationPage />} />
        <Route path="/versions" element={<VersionsPage />} />
        <Route path="/chat" element={<ChatPage />} />
        <Route path="/notifications" element={<NotificationsPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/admin" element={<AdminPage />} />
      </Route>

      {/* 404 Catch-All */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};
